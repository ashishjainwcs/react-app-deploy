import { Button } from "react-bootstrap";
import { addToCartAndUpdate } from "../Utility/SiteHelper";



const AddToCart = ({ label, siteData, productId, updateMainStateData }) => {

    const inputQty = 1;
    const addToCart = (productId) => {
        console.log("add to cart clicked....");

        addToCartAndUpdate(productId, siteData, inputQty);

        console.log("siteDATA::::::",siteData);
        updateMainStateDataChild(siteData);

        return;
    }

    const  updateMainStateDataChild = (siteData) => {
        console.log("parent to child function called... Add to cart");
        updateMainStateData(siteData);
    }
    return <>

        <Button className="btn btn-primary" onClick={() => addToCart(productId, siteData)} >{label}</Button>


    </>


}

export default AddToCart;