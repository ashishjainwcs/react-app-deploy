import Main from "../Main/Main";
import { SiteDataContext } from "../Context/Context";
import React from "react";

class App extends React.Component {

    

    constructor() { // lifecycle
        super();
        console.log("Constructor lifecycle - App.js");
        const siteData = JSON.parse(localStorage.getItem("siteData"));
        console.log(siteData);
        this.state = { siteData };
    }

    render() {


        return <>

            <SiteDataContext.Provider value={this.state.siteData} >
                <Main />
            </SiteDataContext.Provider>

        </>
    }
}

export default App;