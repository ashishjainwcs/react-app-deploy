import Header from "../Header/Header";
import Breadcrumb from "../Main/Breadcrumb";
import CategoryList from "./CategoryList";

function CategoryListPage({siteData}) {


    return <>
        <div className="home-page-container">

            <Header siteData={siteData} />
            <Breadcrumb />

            <CategoryList siteData={siteData}/>

        </div>
    </>
}

export default CategoryListPage;