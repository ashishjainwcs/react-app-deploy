import { Link } from "react-router-dom";


function ProductDetail({ siteData, productProp, indexProp }) {

    const product = productProp;
    const index = indexProp;
    return <>
        <div className="product-detail-container" key={index}>

            <div key={index} className="card h-100" >
                <table>
                    <tbody>
                    <tr>
                        <td>
                            <img src={product.imgSrc} className="card-img-top" alt="..." />

                        </td>
                        <td>
                            <div className="card-body">
                                <h5 className="card-title">{product.productName}</h5>
                                <p className="card-text">Price    : {product.productPrice}</p>
                                <p className="card-text">Category :{product.categoryCode}</p>
                            </div>
                            <div className="card-footer text-center">
                                {siteData.siteData.loggedInUserType !== "" ? <span>
                                    <Link className="btn btn-primary" to="/" >Buy Now</Link>

                                    <Link className="btn btn-primary" to="/" >Add to Cart</Link>
                                </span> : <span>

                                </span>
                                }
                            </div>

                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>

    </>
}
export default ProductDetail;