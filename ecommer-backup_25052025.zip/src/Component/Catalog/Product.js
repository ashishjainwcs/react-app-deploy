import { Link } from "react-router-dom";
import AddToCart from "../order/AddToCart";


function Product({siteData, productProp, indexProp, updateMainStateData}) {

    const product = productProp;
    const index = indexProp;
    
    const  updateMainStateDataChild = (siteData) => {
        console.log("parent to child function called... Product");
        updateMainStateData(siteData);
    }


    return <>
        <div className="col" key={index}>

            <div key={index} className="card h-100" >
                <Link to={`/product-details/${product.productId}`} >
                <img src={product.imgSrc} className="card-img-top" alt="..." />
                <div className="card-body">
                    <h5 className="card-title">{product.productName}</h5>
                    <p className="card-text">Price    : {product.productPrice}</p>
                    <p className="card-text">Category :{product.categoryCode}</p>
                </div>
                </Link>
                <div className="card-footer text-center">
                    {siteData.siteData.loggedInUserType !== "" ? <span>
                        <AddToCart label={"Add to Cart"} siteData={siteData} productId={product.productId} updateMainStateData={(siteData)=>updateMainStateDataChild(siteData)}/>
                        <Link className="btn btn-primary" to="/" >Buy Now</Link>

                        <Link className="btn btn-primary" to="/" >Add to Cart</Link>
                    </span> : <span>

                    </span>
                    }
                </div>
            </div>
        </div>

    </>
}
export default Product;