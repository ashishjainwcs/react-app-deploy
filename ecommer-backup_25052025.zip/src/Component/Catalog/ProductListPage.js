import Header from "../Header/Header";
import Breadcrumb from "../Main/Breadcrumb";
import ProductList from "./ProductList";

function ProductListPage({siteData}) {

    return <>
        <div className="home-page-container">

            <Header siteData={siteData} />
            <Breadcrumb />

            <ProductList siteData={siteData}/>

        </div>
    </>
}

export default ProductListPage;