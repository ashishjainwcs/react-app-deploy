import HomePage from "../Home/HomePage";
import Nav from "./Nav";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import React from "react";
import RegistrationPage from "../Registration/RegistrationPage";
import LoginPage from "../Login/LoginPage";
import CategoryListPage from "../Catalog/CategoryListPage";
import CategoryProductPage from "../Catalog/CategoryProductPage"
import ProductListPage from "../Catalog/ProductListPage";
import ProductDetailPage from "../Catalog/ProductDetailPage";
import AdminHomePage from "../Admin/HomePage/AdminHomePage";
import AdminCategoryListPage from "../Admin/Category/AdminCategoryListPage";
import AdminProductListPage from "../Admin/Products/AdminProductListPage";

class Main extends React.Component {

  constructor() { // lifecycle
    super();
    console.log("Constructor lifecycle - Main.js");
    const siteData = this.getSiteData();
    console.log(siteData);
    this.state = { siteData };
  }

  componentDidUpdate() {
    console.log("Main component did update");
  }

  getSiteData = () => {
    let basicData = JSON.parse(localStorage.getItem("siteData"));
    console.log(basicData);
    if (basicData === null || basicData === undefined) {
      basicData = {"siteData":{"users":[{"userId":1001,"firstName":"testfirst","lastName":"testLast","gender":"M","dateOfBirth":"23/09/1978","address":"Delhi","email":"ashish1@ashish1.com","password":"1234","phoneNumber":"9891198911","userType":"C"},{"userId":1002,"firstName":"testfirst1002","lastName":"testLast","gender":"M","dateOfBirth":"23/09/1978","address":"Delhi","email":"ashish@ashish.com","password":"1234","phoneNumber":"9891198911","userType":"C"},{"userId":1004,"firstName":"Test-Admin","lastName":"Jain","gender":"M","dateOfBirth":"2022-06-15","address":"Delhi, New Delhi","email":"abc@abc.com","password":"1234","phoneNumber":"9891198911","userType":"A"},{"userId":1005,"firstName":"Ashish","lastName":"Jain","gender":"M","dateOfBirth":"2022-06-15","address":"Delhi, New Delhi","email":"abcd@abcd.com","password":"1234","phoneNumber":"9891198911","userType":"A"},{"userId":1006,"firstName":"Ashish1","lastName":"Jain","gender":"M","dateOfBirth":"2025-05-14","address":"Delhi, New Delhi","email":"abcde@abcde.com","password":"1234","phoneNumber":"9891112345","userType":"C"},{"userId":1007,"firstName":"Test001","lastName":"Jain","gender":"M","dateOfBirth":"2025-04-29","address":"Delhi","email":"test1001@test.com","password":"1234","phoneNumber":"98911","userType":"C"},{"userId":1008,"firstName":"Test-User","lastName":"Jain","gender":"M","dateOfBirth":"2025-04-29","address":"Delhi","email":"user@user.com","password":"1234","phoneNumber":"98911","userType":"C"}],"loggedInUser":"Test-Admin","loggedInUserId":1004,"loggedInUserType":"A","categories":[{"categoryId":1001,"categoryName":"Apple2"},{"categoryId":1002,"categoryName":"Samsung"},{"categoryId":1003,"categoryName":"Laptop"},{"categoryId":1004,"categoryName":"Air Conditioner - 2"},{"categoryName":"abcd","categoryId":1005},{"categoryName":"abcd-9","timestamp":"2025-05-22T13:12:07.371Z","categoryId":1006}],"products":[{"productId":1001,"productCode":"1239","productName":"iPhone-6s-new","productPrice":22000,"imgSrc":"https://m.media-amazon.com/images/I/61VuVU94RnL._SX679_.jpg","categoryCode":1001,"timestamp":"2025-05-22T13:35:20.745Z"},{"productId":1002,"productCode":"1235","productName":"iPhone-7s","productPrice":35000,"imgSrc":"https://m.media-amazon.com/images/I/61VuVU94RnL._SX679_.jpg","categoryCode":1001},{"productId":1003,"productCode":"1236","productName":"iPhone-8s","productPrice":35000,"imgSrc":"https://m.media-amazon.com/images/I/61VuVU94RnL._SX679_.jpg","categoryCode":1001},{"productId":1004,"productCode":"1237","productName":"iPhone-9s","productPrice":39000,"imgSrc":"https://m.media-amazon.com/images/I/61VuVU94RnL._SX679_.jpg","categoryCode":1001}],"paymentTypes":["Paypal","Cash on Delivery","Online Payment"],"orders":[{"ordersId":5001,"userId":1001,"products":[{"productId":1001,"productName":"iPhone-6s-new","productCode":1239,"productPrice":39000,"qty":"2"}],"shippingAddress":"Haryana","totalAmount":"50000","status":"P"}],"ordersPayInfo":[{"ordersId":5001,"paymentMode":"Cash on Delivery","orderNotes":"purpose of Order"}]}};
      localStorage.setItem("siteData", JSON.stringify(basicData));
    }
    return JSON.parse(localStorage.getItem("siteData"));

  }

  updateMainStateData= (siteData)=> {
    this.setState(siteData.siteData);
  } 

  render() {

    console.log("Main render method");
    return <BrowserRouter>
      <Routes>
        <Route path="/" element={<Nav />}>
          <Route index element={<HomePage siteData={this.state.siteData} updateMainStateData={(siteData)=>this.updateMainStateData(siteData)}/>} />
          <Route path="/register" element={<RegistrationPage siteData={this.state.siteData} />} />
          <Route path="/login" element={<LoginPage siteData={this.state.siteData} />} />
          <Route path="/categories" element={<CategoryListPage siteData={this.state.siteData} />} />
          <Route path="/categories/:id" element={<CategoryProductPage siteData={this.state.siteData} />} updateMainStateData={()=>this.updateMainStateData()}/>
          <Route path="/shop" element={<ProductListPage siteData={this.state.siteData} updateMainStateData={()=>this.updateMainStateData()}/>} />
          <Route path="/product-details/:id" element={<ProductDetailPage siteData={this.state.siteData} updateMainStateData={()=>this.updateMainStateData()}/>} />
          <Route path="/admin-page" element={<AdminHomePage siteData={this.state.siteData} />} />
          <Route path="/admin-category" element={<AdminCategoryListPage siteData={this.state.siteData} />} />
          <Route path="/admin-product" element={<AdminProductListPage siteData={this.state.siteData} />} />
        </Route>
      </Routes>
    </BrowserRouter>
  }
}


export default Main;
