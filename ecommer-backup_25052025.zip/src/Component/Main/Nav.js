import { Outlet } from "react-router-dom";

function Nav() {
  return (
    <>
      <div>
        <Outlet />
      </div>
    </>
  );
}

export default Nav;
