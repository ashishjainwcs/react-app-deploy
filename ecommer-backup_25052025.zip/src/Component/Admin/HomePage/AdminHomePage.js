import { useEffect } from "react";
import Header from "../../Header/Header";
import Breadcrumb from "../../Main/Breadcrumb";
import { useNavigate } from "react-router-dom";
import AdminCatalogManagementPage from "./AdminCatalogManagementPage";
import { SiteDataContext } from "../../Context/Context";

function HomePage({ siteData }) {

    const navigate = useNavigate();

    useEffect(() => {

        if (siteData.siteData.loggedInUserType !== "A") {
            navigate('/');
        }

    }, [])


    if (siteData.siteData.loggedInUserType !== "A") {
        return;
    } else {

        return <>

            <div className="home-page-container">
                <SiteDataContext.Provider value={siteData} >
                    <Header siteData={siteData} />
                    <Breadcrumb />
                    <AdminCatalogManagementPage  siteData={siteData}/>
                </SiteDataContext.Provider>
            </div>
        </>;
    }
}

export default HomePage;