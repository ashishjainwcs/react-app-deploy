import Header from "../../Header/Header";
import Breadcrumb from "../../Main/Breadcrumb";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import AdminCategoryList from "./AdminCategoryList";
import { useContext } from "react";
import { useState } from "react";
import { updateSiteData, categoryNameAvailable, getNextCategoryId, categoryNameAvailableNew } from "../../Utility/SiteHelper";

function AdminCategoryListPage({ siteData }) {

    console.log("Admin Category List Page");
    const navigate = useNavigate();
    const [siteDataState, setSiteDataState] = useState(siteData);
    const [errorCategory, setErrorCategory] = useState("");

    useEffect(() => {

        if (siteData.siteData.loggedInUserType !== "A") {
            navigate('/');
        }

    }, [])

    const navdata = [{
        path: 'admin-page',
        displayText: 'Manage Site'
    }];

    /* function passed in child component AdminCategoryList to take input of updated Category data*/
    const updateCategory = (updatedCategory) => {
        setErrorCategory("");
        if (categoryNameAvailable(siteData, updatedCategory)) {
            let updatedCategories = siteData.siteData.categories.map((category, index) => {

                console.log(category);
                if (category.categoryId === updatedCategory.categoryId) {
                    return updatedCategory;
                } else {
                    return category;
                }
            });
            siteData.siteData.categories = updatedCategories;
            updateSiteData(siteData);
            setSiteDataState({
                ...siteData
            })
        } else {
            console.log("false received");
            /* adding timestamp so that the child component useEfft method dependency changes */
            updatedCategory = ({
                ...updatedCategory,
                timestamp: new Date()
            }
            )
            setErrorCategory(updatedCategory);
        }


    }

    /* function passed in child component AdminCategoryList to take input of Category to be deleted*/
    const deleteCategory = (id) => {
        let updatedCategories = siteDataState.siteData.categories.filter((category) =>
            category.categoryId !== id
        )

        siteData.siteData.categories = updatedCategories;
        updateSiteData(siteData);
        setSiteDataState({
            ...siteData
        })
    }

    /* function passed in child component AdminCategoryList to take input of Category to be deleted*/
    const addCategory = (category) => {

        setErrorCategory("");
        if (categoryNameAvailableNew(siteData, category)) {

            const addCategory = {
                ...category,
                categoryId: getNextCategoryId(siteDataState.siteData.categories),
            }

            siteData.siteData.categories = [...siteData.siteData.categories, addCategory];
            updateSiteData(siteData);
            setSiteDataState({
                ...siteData
            })
            console.log("add category site data state");
            console.log(siteDataState);
        } else {
            console.log("false received");
            /* adding timestamp so that the child component useEfft method dependency changes */
            category = ({
                ...category,
                timestamp: new Date()
            }
            )
            setErrorCategory(category);
        }

    }

    if (siteData.siteData.loggedInUserType !== "A") {
        return;
    } else {

        return <>
            <div className="home-page-container">

                <Header siteData={siteData} />
                <Breadcrumb navData={navdata} />

                <AdminCategoryList categories={siteDataState.siteData.categories}
                    onUpdateCategory={(updatedCategory) => updateCategory(updatedCategory)}
                    onDeleteCategory={(id) => deleteCategory(id)}
                    onAddCategory={(categoryName) => addCategory(categoryName)}
                    errorCategory={errorCategory}
                />

            </div>
        </>
    }
}

export default AdminCategoryListPage;