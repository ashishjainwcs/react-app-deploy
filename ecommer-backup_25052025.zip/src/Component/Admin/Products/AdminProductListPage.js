import Header from "../../Header/Header";
import Breadcrumb from "../../Main/Breadcrumb";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import AdminProductList from "./AdminProductList";
import { useState } from "react";
import {productNameAvailable, updateSiteData, productNameAvailableNew, getNextProductId} from '../../Utility/SiteHelper';

function AdminProductListPage({ siteData }) {

    console.log("Admin Product List Page");
    const navigate = useNavigate();
    const [siteDataState, setSiteDataState] = useState(siteData);
    const [errorProduct, setErrorProduct] = useState("");


    useEffect(() => {

        if (siteData.siteData.loggedInUserType !== "A") {
            navigate('/');
        }

    }, [])

    const navdata = [{
        path: 'admin-page',
        displayText: 'Manage Site'
    }];


    /* function passed in child component AdminCategoryList to take input of updated Product data*/
    const updateProduct = (updatedProduct) => {
        setErrorProduct("");
        if (productNameAvailable(siteData, updatedProduct)) {
            let updatedProducts = siteData.siteData.products.map((product, index) => {

                console.log(product);
                if (product.productId === updatedProduct.productId) {
                    console.log("productPrice", updatedProduct.productPrice);
                    updatedProduct.productPrice = parseInt(updatedProduct.productPrice);
                    return updatedProduct;
                } else {
                    return product;
                }
            });
            siteData.siteData.products = updatedProducts;
            updateSiteData(siteData);
            setSiteDataState({
                ...siteData
            })
        } else {
            console.log("false received");
            /* adding timestamp so that the child component useEfft method dependency changes */
            updatedProduct = ({
                ...updatedProduct,
                lastFailedUpdateDate: new Date()
            }
            )
            setErrorProduct(updatedProduct);
        }
    }


    /* function passed in child component AdminCategoryList to take input of updated Product data*/
    const addProduct = (addedProduct) => {
        setErrorProduct("");
        if (productNameAvailableNew(siteData, addedProduct)) {


            const newProductObject = {
                ...addedProduct,
                productId: getNextProductId(siteDataState.siteData.products),
            }
            siteData.siteData.products = [...siteData.siteData.products, newProductObject];
            updateSiteData(siteData);
            setSiteDataState({
                ...siteData
            })
        } else {
            console.log("false received");
            /* adding timestamp so that the child component useEfft method dependency changes */
            addedProduct = ({
                ...addedProduct,
                lastFailedUpdateDate: new Date()
            }
            )
            setErrorProduct(addedProduct);
        }
    }


    /* function passed in child component AdminCategoryList to take input of Category to be deleted*/
    const deleteProduct = (id) => {
        let updatedProducts = siteDataState.siteData.products.filter((product) =>
            product.productId !== id
        )

        siteData.siteData.products = updatedProducts;
        updateSiteData(siteData);
        setSiteDataState({
            ...siteData
        })
    }



    if (siteData.siteData.loggedInUserType !== "A") {
        return;
    } else {

        return <>
            <div className="home-page-container">

                <Header siteData={siteData} />
                <Breadcrumb navData={navdata} />

                <AdminProductList products={siteDataState.siteData.products}
                    categories={siteDataState.siteData.categories}
                    onUpdateProduct={(updatedProduct) => updateProduct(updatedProduct)}
                    errorProduct={errorProduct}
                    onAddProduct={(addedProduct) => addProduct(addedProduct)}
                    onDeleteProduct={(productId) => deleteProduct(productId)}

                />

            </div>
        </>
    }
}

export default AdminProductListPage;