
import Product from "../Catalog/Product";

function RecommendedProducts({siteData, updateMainStateData}) {
    console.log("userYype " + siteData.siteData.loggedInUserType);


 const  updateMainStateDataChild = (siteData) => {
        console.log("parent to child function called... recommended");
        updateMainStateData(siteData);
    }



    return <>

        <h1> Recommended Products </h1>
        <div className="row row-cols-1 row-cols-md-3 g-4">
            {siteData.siteData.products.map((product, index) => (
                index < 3 &&
                <Product productProp={product} indexProp={index} siteData={siteData} updateMainStateData={(siteData)=>updateMainStateDataChild(siteData)}/>

            ))
            }
        </div>
    </>
}

export default RecommendedProducts;