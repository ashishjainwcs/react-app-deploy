import { createContext } from 'react';

export const SiteDataContext = createContext('siteData');