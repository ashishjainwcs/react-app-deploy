import Header from "../Header/Header";
import Breadcrumb from "../Main/Breadcrumb";

import RegistrationForm from "./RegistrationForm";


function RegistrationPage({ siteData }) {


    return <>
        
        <div className="home-page-container" >

            <Header siteData={siteData} />
            <Breadcrumb />
            < RegistrationForm siteData={siteData} />
        </div>

    </>
}

export default RegistrationPage;