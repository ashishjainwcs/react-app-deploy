
import cartLogo from "./../../images/cart.svg";


const MiniCart = ({ order, userId }) => {


    console.log("minicart", order);

    const handleShowCart = () => {
        var element = document.getElementById("miniCartIcon");
        element.classList.toggle("displayBlock");
        window.addEventListener('click', function (e) {
            if (document.getElementById('miniCartParentIcon').contains(e.target)) {
                console.log("inside");
            } else {
                console.log("outside");
                document.getElementById('miniCartIcon').classList.remove("displayBlock");
            }
        });

    }


    return <>
        <div className="mini-cart-container" id="miniCartParentIcon">
            <button variant="link" onClick={() => handleShowCart()} title="Boots Logo" className="">
                {" "}
                <img
                    src={cartLogo}
                    border="0"
                    alt="Site Logo"
                    className="cart-logo"
                />{" "}
            </button>

            <ul className="mini-cart-content" id="miniCartIcon">
                {order !== null && order !== undefined && Object.keys(order).length > 0 && order.products.length > 0 ?
                    <li className="mini-cart-suggestion" >

                        <table className="table table-hover">
                            <thead className="thead-dark">
                                <tr>
                                    <th scope="col" colSpan={3} > Your Basket</th>
                                </tr>
                                <tr>
                                    <th scope="col"> Product</th>
                                    <th scope="col">  Price </th>
                                    <th scope="col">  Quantity </th>
                                </tr>
                            </thead>
                            <tbody>
                                {order.products.map((product, index) =>
                                    <>
                                        <tr key={index}>
                                            <td> {product.productCode} </td>
                                            <td> {product.productPrice} </td>
                                            <td> {product.qty} </td>
                                        </tr>

                                        <tr>
                                            <td colSpan={3}>
                                                Product Total : {product.productPrice * product.qty}
                                            </td>
                                        </tr>
                                    </>


                                )}
                                <tr>
                                    <td colSpan={3}>
                                        Order Total : {order.totalAmount}
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </li>
                    :
                    <li>not order found {userId}</li>

                }
            </ul>
        </div>




    </>






};

export default MiniCart;